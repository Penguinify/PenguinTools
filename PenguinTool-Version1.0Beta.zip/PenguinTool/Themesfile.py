class base:
    one = "\033[1;37m"
    two = "\033[1;37m"
    b = ''
    e = ''
    i = "\033[1;35m"
    display_name = 'Default'
class ice:
    one = "\033[0;34m"
    two = "\033[0;36m"
    b = "\033[1m"
    e = "\033[0m"
    i = "\033[1;35m"
    display_name = 'Icy'
class racer:
    one = "\033[0;31m"
    two =  "\033[0;37m"
    b = "\033[1m"
    e = "\033[0m"
    i = "\033[1;35m"
    display_name = 'Racer'
class summer:
    one = "\033[1;33m"
    two = "\033[1;34m"
    b = "\033[1m"
    e = "\u001b[0m"
    i = "\033[1;35m"
    display_name = 'Summer'
def load():
    global themes
    import sys, inspect
    themesraw = inspect.getmembers(sys.modules[__name__], inspect.isclass)
    themes = []
    i = 0
    while i < len(themesraw):
        a = themesraw[i]
        themes.append(a[1])
        i += 1
    i = themes[0]
    return themes
