print('Loading PenguinTools Version 1.0 Basic')
from importlib import *
import importlib
import os
import csv
from random import randint
directory = os.getcwd()
all_files = os.listdir(directory)
global themes
from Themesfile import *
themes = load()

custom_applications = []



alphabet = ['»','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','`','1','2','3','4','5','6','7','8','9','0','~','!','@','#','$','%','^','&','*','(',')','_','»']

csv_files = list(filter(lambda f: f.endswith('.csv'), all_files))



# Loading
def createaccount():
    global new_username
    global theme
    theme = base
    print(
        'Please start by entering your name.')
    new_username = input('>>> ')
    print(''
          '')
    print(f'Why hello there, {new_username}. Why not create a password too?')
    createpassword()

def createpassword():
    global new_password
    print('Please enter a Password')
    new_password = input('>>> ')
    print('Please confirm your password')
    new_password_confirm = input('>>> ')
    try:
        if new_password == new_password_confirm:
            x = 0
            for a in new_password:
                if a in alphabet:
                    pass
                else:
                    x += 1
            if not x == 1:
                print('Your password has been confirmed. We are currently creating your account file (This will be stored on your computer).')
                storeddata = themes.index(base)
                code = ''
                for a in new_password:
                    adding = str(randint(-1, 1))
                    if adding == '-1':
                        adding == '-'
                    code = code + adding

                new_password_encoded = ''
                loop = 0
                for i in new_password:
                    if code[loop] == '-':
                        adding = -1
                    if code[loop] == '1':
                        adding = 1
                    if code[loop] == '0':
                        adding = 0
                    new_password_encoded = new_password_encoded + alphabet[alphabet.index(i) + adding]
                    loop += 1
                header = ['name', 'password', 'encryptioncode', 'data']
                data = [new_username, new_password_encoded, code, storeddata]

                with open(new_username + '.csv', 'w', encoding='UTF8', newline='') as f:
                    writer = csv.writer(f)

                    # write the header
                    writer.writerow(header)

                    # write multiple rows
                    writer.writerow(data)
                print('Your account has been created. Please restart the project!')
            else:
                print('Sorry, your password contains illegal characters')
                createpassword()
        else:
            print('''
Passwords do not match!
            ''')
            createpassword()
    except:
        print('''




        ''')
        print(''' 

        
\nSorry, your password contains illegal characters\n


 ''')
        createpassword()

def passwordlogin():
    print('')
    global encrypted_passcode
    print(theme.one + 'Welcome back ' + username + '. Please enter your password')
    i = input(theme.i + '>>> ')
    encrypted_passcode, loop, encryption_code = '', 0, rows[2]
    for a in i:
        if encryption_code[loop] == '-':
            adding = -1
        if encryption_code[loop] == '1':
            adding = 1
        if encryption_code[loop] == '0':
            adding = 0
        encrypted_passcode = encrypted_passcode + alphabet[alphabet.index(a) + adding]
        loop += 1
    if encrypted_passcode == rows[1]:
        print(theme.one + 'You have successfully logged in!')
        bootup()
    else:
        print(theme.one + 'You have entered your passcode wrong.')
        passwordlogin()

def console():
    print('')
    print(theme.two + 'Welcome to the Console type "help" for a list of commands')
    console = True
    while console == True:
        i = input(theme.i + '>>> ')
        if i == 'help':
            print(theme.one + '''List of Commands:
help
exit
install <none>''')
        if i == 'exit':
            print(theme.one + 'Quitting Console')
            console = False
            bootup()

def calculator():
    print('')
    print(theme.one + 'Welcome to Calculator, press enter to exit')
    while True:
        print(theme.two + 'Please write your equation')
        i = input(theme.i + '>>>')
        if i == '':
            bootup()
        try:
            print('')
            print(theme.one + '''The Answer is ''' + str(eval(i)))
            print('')
        except:
            print(theme.two + '''Sorry but your equation has raised an error, please try again.
            ''')

def settings():
    global theme
    print('')
    print(theme.one + theme.b + 'Welcome to Settings!' + theme.e)
    print(theme.two + '1) About')
    print('2) Themes')
    print('Press Enter to Exit')
    i = input(theme.i + '>>> ')

    if i == '1':
        print('')
        print(theme.one + theme.b + 'System Info' + theme.e)
        print(theme.two + f'''Running PenguinTools V1.0 Beta Test
Theme: {theme}''')
        print(theme.one + theme.b + 'User Info' + theme.e)
        print(theme.two + f'''UserID: {username}
Password: {encrypted_passcode} (Due to our safety restrictions, we do not store your exact password anywhere.)''')
        print('')
        settings()
    if i == '2':
        a = 0
        while a < len(themes):
            print(themes[a].one + str(a + 1) + ') ' + themes[a].display_name )
            a += 1
        print(theme.two + 'Press Enter to Exit')
        i = input(theme.i + '>>> ')
        try:
            theme = themes[int(i) - 1]
        except:
            print('Input Error, please try again')
        settings()

    if i == '3':
        bootup()
    if i == '':
        bootup()
    else:
        settings()

def save(storeddata):
    storeddata = themes.index(storeddata)
    header = ['name', 'password', 'encryptioncode', 'data']
    data = [rows[0], rows[1], rows[2], storeddata]

    with open(rows[0] + '.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.writer(f)

        # write the header
        writer.writerow(header)

        # write multiple rows
        writer.writerow(data)
    exit(theme.one + 'Goodbye! Cya next time!')

def bootup():
    print(theme.one + theme.b +'''———————————————————————
PENGUINTOOLS -- Please open an application''' + theme.e)
    print(theme.two + '1) Console')
    print('2) Settings')
    print('3) Basic Calculator')
    try:
        o = len(custom_applications) / 2
        loop = -1
        a = 3
        numbers = []
        while o > loop:
            loop += 2
            a += 1
            print(str(a) + ') ' + custom_applications[loop])
            numbers.append(str(a))
    except:
        pass

    print('Press Enter to Exit')
    i = input(theme.i +'>>> ')
    if i == '1':
        console()
    if i == '2':
        settings()
    if i == '3':
        calculator()
    if i == '':
        save(theme)
    if i in numbers:
        application =  custom_applications[numbers.index(i) * 2]
        try:
            application.main(theme)
        except:
            application.main()
        bootup()
    else:
        bootup()


print('PenguinTools Loaded')
print('')
print('Welcome to PenguinTools!')


#Startup/login
if not csv_files == []:
    print('Hello we have found a save! Would you like to load it? (y/n)')
    i = input('>>> ')
    if i == 'y':
        print('')
        if len(csv_files) >= 1:
            print('We found more than one save file, which one is yours? (Please write the number in order of appearance)')
            for csv in csv_files:
                print(csv)
            i = int(input('>>> '))
            import csv
            loadfile = csv_files[i - 1]
            print(loadfile)
            print('Loading')
            rows = []
            try:
                with open(loadfile, 'r') as file:
                    csvreader = csv.reader(file)
                    header = next(csvreader)
                    for row in csvreader:
                        rows.append(row)
            except:
                exit('Forced Exit # Invalid/Corrupted Save File')

            rows = rows[0]
            username = rows[0]
            i = rows[3]
            theme = themes[int(i[0])]
            passwordlogin()



    if i == 'n':
        createaccount()
    else:
        print('Invalid Input')

if csv_files == []:
    createaccount()




